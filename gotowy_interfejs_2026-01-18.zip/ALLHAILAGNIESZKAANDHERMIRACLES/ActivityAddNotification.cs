﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALLHAILAGNIESZKAANDHERMIRACLES
{
    public partial class ActivityAddNotification : Form
    {
        Panel _panel7;
        TableLayoutPanel _tableLayoutPanel3;

        public ActivityAddNotification(Panel panel7, TableLayoutPanel tableLayoutPanel3)
        {
            Panel _panel7 = new Panel();
            InitializeComponent();
            this._panel7 = panel7;
            _tableLayoutPanel3 = tableLayoutPanel3;
        }

        //private void label1_Click(object sender, EventArgs e)
        //{
        //}
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void confirmButton_Click(object sender, EventArgs e)
        {
            String activityDesc = textBox1.Text;
            var activity = new UIActivityObject(_panel7, activityDesc);
            _tableLayoutPanel3.Controls.Add(activity);
            this.Close();
            
            //Form1.setDescription(activityDesc);
        }
    }
}
