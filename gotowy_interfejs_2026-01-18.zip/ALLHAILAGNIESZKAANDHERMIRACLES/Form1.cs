using Accessibility;
using Activity.Domain.Services;

namespace ALLHAILAGNIESZKAANDHERMIRACLES
{

    public partial class Form1 : Form
    {
        private int _projectCount = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (_projectCount < 9)
            {
                _projectCount++;
                var project = new UIProjectObject(_projectCount, panel1, "default");
                tableLayoutPanel1.Controls.Add(project);

                ProjectService defaultService = new ProjectService();
                defaultService.AddProject("firstProject", "firstDescription");
            }
            else
            {
                MessageBox.Show("You've reached the maximum project count!", "Warning");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var task = new UITaskObject(panel4);
            tableLayoutPanel2.Controls.Add(task);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var activityAddNotification = new ActivityAddNotification(panel7, tableLayoutPanel3);
            activityAddNotification.Show();
        }

        private void tableLayoutPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //tutaj jest dodane powiadomienie tylko �eby sprawdzi� czy dzia�a -> sprawdzone, dzia�a :)) Nale�y je przenie��
            //w taki sposob aby wyskakiwa�o co p� godziny, a nie na reakcje na przycisk
            ToastNotification toast = new ToastNotification();
            toast.Show();

            //tutaj kod pojawiania si� faktycznego forma pod tworzenie podsumowania tygodniowego

            weeklySummary weeklySummary = new weeklySummary();
            weeklySummary.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           monthlySummary monthlySummary = new monthlySummary();
           monthlySummary.Show();
        }
    }
}
