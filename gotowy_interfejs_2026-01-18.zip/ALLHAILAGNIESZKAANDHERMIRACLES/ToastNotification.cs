﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALLHAILAGNIESZKAANDHERMIRACLES
{
    public partial class ToastNotification : Form
    {
        int toastX, toastY;
        public ToastNotification()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ToastNotification_Load(object sender, EventArgs e)
        {
            position();
        }

        private void toastTimer_Tick(object sender, EventArgs e)
        {
            toastY -= 10;
            this.Location = new Point(toastX, toastY);
            if(toastY <= 940)
            {
                toastTimer.Stop();
            }
        }

        private void position()
        {
            int screenW = Screen.PrimaryScreen.WorkingArea.Width;
            int screenH = Screen.PrimaryScreen.WorkingArea.Height;

            toastX = screenW - this.Width;
            toastY = screenH - this.Height + 70;

            this.Location = new Point(toastX, toastY);
        }
    }
}
