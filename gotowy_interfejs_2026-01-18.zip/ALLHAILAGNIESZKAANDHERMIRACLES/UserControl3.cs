﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ALLHAILAGNIESZKAANDHERMIRACLES
{
    public partial class UIActivityObject : UserControl
    {
        private Panel _panel7;
        private String _activityDescription;
        public UIActivityObject(Panel panel7, String activityDescription)
        {
            _panel7 = panel7;
            InitializeComponent();
            activityBox.Text = activityDescription;
        }

        private void activityBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
